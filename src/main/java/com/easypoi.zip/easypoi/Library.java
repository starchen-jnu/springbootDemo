package com.easypoi;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.excel.annotation.ExcelCollection;
import cn.afterturn.easypoi.excel.annotation.ExcelEntity;
import cn.afterturn.easypoi.excel.annotation.ExcelTarget;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: StarC
 * @Date: 2020/6/15 15:12
 * @Description:
 */
@ExcelTarget("Library")
public class Library implements Serializable {

    private String id;

    @Excel(name = "序号",orderNum = "1",mergeVertical=true)
    private String order;
    @Excel(name = "项目",mergeVertical = true)
    private String project;
    @ExcelCollection(name = "事项")
    private List<ItemEntity>items;
    @ExcelCollection(name = "依据")
    private List<BasisEntity> basisEntities;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public List<ItemEntity> getItems() {
        return items;
    }

    public void setItems(List<ItemEntity> items) {
        this.items = items;
    }

    public List<BasisEntity> getBasisEntities() {
        return basisEntities;
    }

    public void setBasisEntities(List<BasisEntity> basisEntities) {
        this.basisEntities = basisEntities;
    }
}
