package com.easypoi;

import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.util.PoiPublicUtil;


import java.io.File;
import java.util.List;

/**
 * @Author: StarC
 * @Date: 2020/6/15 15:53
 * @Description:
 */
public class Test {

    public static void main(String[] args) {
        ImportParams params = new ImportParams();
//        params.setTitleRows(2);
        params.setHeadRows(2);
        File file = new File("D:/kongfang20200603.xlsx");
        List<Library>list =  ExcelImportUtil.importExcel(
                file,
                Library.class, params);
        System.out.println(list);
    }
}
