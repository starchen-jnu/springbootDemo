package com.easypoi;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.excel.annotation.ExcelTarget;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.annotation.Target;

/**
 * @Author: StarC
 * @Date: 2020/6/15 15:33
 * @Description:
 */


public class BasisEntity implements Serializable {

    private String id;

    @Excel(name = "依据名称")
    private  String name;

    @Excel(name = "依据条款")
    private String clause;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClause() {
        return clause;
    }

    public void setClause(String clause) {
        this.clause = clause;
    }
}
